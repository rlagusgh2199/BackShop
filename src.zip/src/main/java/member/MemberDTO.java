package member;

public class MemberDTO {
   private String id2;
   private String pwd1;
   private String pwd2;
   private String alias;
   private String address;
   private String email;
   private String gender;
   private String favorite;
   
   
   public String getId2() {
      return id2;
   }
   public void setId2(String id2) {
      this.id2 = id2;
   }
   public String getPwd1() {
      return pwd1;
   }
   public void setPwd1(String pwd1) {
      this.pwd1 = pwd1;
   }
   public String getPwd2() {
      return pwd2;
   }
   public void setPwd2(String pwd2) {
      this.pwd2 = pwd2;
   }
   public String getAlias() {
      return alias;
   }
   public void setAlias(String alias) {
      this.alias = alias;
   }
   public String getAddress() {
      return address;
   }
   public void setAddress(String address) {
      this.address = address;
   }
   public String getEmail() {
      return email;
   }
   public void setEmail(String email) {
      this.email = email;
   }
   public String getGender() {
      return gender;
   }
   public void setGender(String gender) {
      this.gender = gender;
   }
   public String getFavorite() {
      return favorite;
   }
   public void setFavorite(String favorite) {
      this.favorite = favorite;
   }
   
   
}
